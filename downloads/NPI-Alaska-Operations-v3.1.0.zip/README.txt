ALASKA NPI OPERATIONS 3.1.0 — ONE COMPLETE PACKAGE

Open START-HERE.html. Existing installation: apply migration 007 AFTER existing 006 (older installations follow START-HERE), update the npi-admin Edge Function, update LiveSync.gs using the same existing secrets, then deploy the contents of frontend/ to your existing npi-alaska Cloudflare Pages project. Do not rerun 001/002/003 or change DNS.

NPI configures contract line/sub-line items and company site access. Companies invite/approve workers; workers prepare their own visits without daily assignments. NPI inspects original attendance, GPS, photos and hours before final work approval. Billing is excluded.

This ZIP includes all application/SQL/function/workbook source. It contains public configuration only, no server secret, private contracts, prices or seeded records. Installation/live cloud acceptance is still required; local tests are not proof of a completed remote deployment.
