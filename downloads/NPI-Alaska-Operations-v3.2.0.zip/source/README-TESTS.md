From this folder: npm ci; npm test; npx playwright install chromium; npm run test:e2e.
Tests use isolated SQL and intercepted fictional cloud responses, not production credentials.
Training reproduction requires the tools/model documented in ../training/MEDIA-SOURCES.md.
Deploy only ../frontend/. Historical prototype source is retained solely for regression coverage.
