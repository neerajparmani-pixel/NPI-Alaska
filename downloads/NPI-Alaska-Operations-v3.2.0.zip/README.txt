ALASKA NPI OPERATIONS v3.2.0 — COMPLETE PACKAGE

Extract the entire ZIP and open START-HERE.html. Videos, captions and instructions are included.

EXISTING INSTALLATION: apply migration 008 only AFTER 007. Replace the existing Edge Function with backend/supabase/npi-admin.ts, update the bound workbook LiveSync.gs, and deploy the CONTENTS of frontend/ to the same Cloudflare Pages project. Preserve current accounts, data, workbook and domain. Do not repeat 001–007 or change app DNS.

This package is configured for the existing swift-processor endpoint and alaska.npi6030.com. A verified Resend email sender is required before new signup/recovery. Existing logins remain active. New email-bound invitations support multiple NPI and subcontractor admins; people choose their own private credentials, verify email and await approval. Old unused invitation links are revoked by migration 008.

Reports include all matching authorised rows in CSV/Excel, PDF summaries and selected private evidence originals. The approved layout, logo, site photos and worker-led GPS/photo/hour workflow remain. Billing and invoices are excluded.

Deploy only frontend/. source/ contains complete regression tests and their imports, including historical source-only prototypes. No actual contracts, prices, passwords or server keys are included. Local checks are not proof of live cloud acceptance. Follow START-HERE before real shifts.
