ALASKA NPI OPERATIONS 1.0 — ONE COMPLETE PACKAGE

Open START-HERE.html. Existing installation: apply only migration 004, update the npi-admin Edge Function, update LiveSync.gs using the same existing secrets, then deploy the contents of frontend/ to your existing npi-alaska Cloudflare Pages project. Do not rerun 001/002/003 or change DNS.

NPI invites company administrators; companies invite and approve their workers and manage their own assignments. NPI inspects original attendance, GPS, photos and hours before final work approval. Billing is excluded.

This ZIP includes all application/SQL/function/workbook source. It contains public configuration only, no server secret, private contracts, prices or seeded records. Installation/live cloud acceptance is still required; local tests are not proof of a completed remote deployment.
