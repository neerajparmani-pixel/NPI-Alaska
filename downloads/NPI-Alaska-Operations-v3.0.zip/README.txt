ALASKA NPI OPERATIONS 2.0 — ONE COMPLETE PACKAGE

Open START-HERE.html. Existing installation: apply migration 006 AFTER your existing005 (apply005 first only if not already installed), update the npi-admin Edge Function, update LiveSync.gs using the same existing secrets, then deploy the contents of frontend/ to your existing npi-alaska Cloudflare Pages project. Do not rerun 001/002/003 or change DNS.

NPI configures contract line/sub-line items and company site access. Companies invite/approve workers; workers prepare their own visits without daily assignments. NPI inspects original attendance, GPS, photos and hours before final work approval. Billing is excluded.

This ZIP includes all application/SQL/function/workbook source. It contains public configuration only, no server secret, private contracts, prices or seeded records. Installation/live cloud acceptance is still required; local tests are not proof of a completed remote deployment.
