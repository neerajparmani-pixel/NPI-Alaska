function n(a=!1){return`<span class="brand-monogram${a?" brand-mark-large":""}" role="img" aria-label="NPI wordmark">NPI<span aria-hidden="true">★</span></span>`}export{n as b};
